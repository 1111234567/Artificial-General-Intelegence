"""A physical taste task with independently timed single-tick odor and habitat pulses."""
from dataclasses import dataclass
import os

import numpy as np

from . import mixture_world as game, world


def timing(seeds, trials):
    odor = np.empty((len(seeds), trials), np.int8)
    ctx = np.empty_like(odor)
    for j, seed in enumerate(seeds):
        rng = np.random.default_rng(np.random.SeedSequence([seed, 195319]))
        order = rng.random(trials) < .5
        early = rng.integers(0, 2, size=trials)
        late = rng.integers(2, 4, size=trials)
        odor[j] = np.where(order, early, late)
        ctx[j] = np.where(order, late, early)
    return odor, ctx


class FlashBody(game.Body):
    def __init__(self, menu, **kwargs):
        self.odor_tick, self.context_tick = timing(menu.body.seeds, menu.body.trials)
        super().__init__(menu, **kwargs)

    def observe(self):
        obs = super().observe()
        j, t = self.trial_index, self.tick_index
        obs[self.odor_tick[:, j] != t, game.LEFT.start:game.RIGHT.stop] = .5
        obs[self.context_tick[:, j] != t, game.CTX] = 0.
        return obs


def rollout(agent, menu, **kwargs):
    sim = FlashBody(menu, **kwargs)
    agent.reset(menu.body.n)
    obs = sim.observe()
    while obs is not None:
        obs = sim.step(agent.act(obs))
    return sim.result()


